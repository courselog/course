export interface LoggerConfig{
    applicaitonName: string;
}