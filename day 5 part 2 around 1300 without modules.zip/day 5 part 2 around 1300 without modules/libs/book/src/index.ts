export * from './lib/book/book.component';

export * from './lib/book/book.interface';
export * from './lib/book/books.service';
