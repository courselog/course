export interface Environment {
    appName: string;
}