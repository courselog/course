import { Environment } from "./environemnt.interface";

export const environment: Environment = {
    appName: 'KUKU PRODUCTION'
};
