export interface Book{
    id: string;
    title: string;
    description: string;
    price: number;
    preivewImgUrl: string;

}