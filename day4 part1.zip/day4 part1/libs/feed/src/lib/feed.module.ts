import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { feedRoutes } from './lib.routes';
import { FeedComponent } from './feed/feed.component';
import { BookComponentModule } from '@office/books';
import { ButtonComponentModule, CarouselComponentModule } from '@office/ui-components';

@NgModule({
  imports: [
    CommonModule, 
    RouterModule.forChild(feedRoutes),
    BookComponentModule,
    CarouselComponentModule,
    ButtonComponentModule
  ],
  declarations: [FeedComponent],
})
export class FeedModule { }
