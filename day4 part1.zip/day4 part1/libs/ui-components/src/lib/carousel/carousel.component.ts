/* eslint-disable @typescript-eslint/no-inferrable-types */
import { DOCUMENT } from '@angular/common';
import { AfterViewInit, ChangeDetectionStrategy, Component, Inject, Input } from '@angular/core';

export type direction = 'left' | 'right';

@Component({
  selector: 'o-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CarouselComponent implements AfterViewInit {
  @Input() slides: string[] = [];
  selectedIndex: number = 0;
  slidesPositions: any[] = [];

  constructor(@Inject(DOCUMENT) private document: Document) { }
  ngAfterViewInit(): void {
    this.document.querySelectorAll('.slide')
      .forEach((div: any) => {
        this.slidesPositions.push(div.offsetLeft)
      })
  }

  onSlide(dir: direction){
    this.selectedIndex=this.clamp(this.selectedIndex,dir);

    this.document.querySelector('.slider')?.scrollTo({
      left: this.slidesPositions[this.selectedIndex],
      behavior: 'smooth'
    })
  }

  clamp(value: number, dir: direction): number {
    let result = value;

    if(this.slides?.length > 0) {
      const difference = dir=='right'? 1 : -1;
  
      result+=difference;

      if(result<0){
        result=this.slides?.length -1;
      }
      else 
        result=result%this.slides?.length;
      }
      // result=(result+difference)%this.slides?.length;
      return result;
  }
}

