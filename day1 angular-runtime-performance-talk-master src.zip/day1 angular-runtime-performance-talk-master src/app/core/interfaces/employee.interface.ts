export interface Employee {
    name: string;
    number: number;
}
