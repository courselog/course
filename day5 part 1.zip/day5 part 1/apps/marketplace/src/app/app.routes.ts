import { Route } from '@angular/router';

export const appRoutes: Route[] = [
    {
        path: '',
        pathMatch: 'full',
        redirectTo: 'feed'
    },
    {
        path: 'feed',
        loadChildren: () => import('@office/feed').then(m => m.feedRoutes)
    },
    {
        path: 'cart',
        loadChildren: () => import('@office/cart').then(m => m.cartRoutes)
    }
];
