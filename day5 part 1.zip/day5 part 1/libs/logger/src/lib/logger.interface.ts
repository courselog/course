export interface LoggerConfig {
    appName: string;
}