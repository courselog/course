import { Inject, Injectable } from '@angular/core';
import { LoggerConfig as LoggerConfig } from './logger.interface';
import { LOGGER_CONFIG } from './logger.token';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {
  constructor(@Inject(LOGGER_CONFIG) private loggerConfig: LoggerConfig){}

  log(msg:string){
    console.group('Application Name ', this.loggerConfig.appName);
    console.log('LOGGER MSG: ', msg);
    console.groupEnd();
  }
}
